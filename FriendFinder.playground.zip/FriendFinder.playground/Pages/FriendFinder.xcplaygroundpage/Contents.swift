//: Playground - noun: a place where people can play

import UIKit

class Person:NSObject{
    var name:String
    var friends:[Person] = []
    
    init(with name:String) {
        self.name = name
        // self.friends = []
    }
    
    func addFriend(friend:Person){
        self.friends.append(friend)
    }
    
    func printFriends(){
        print("\(name) has \(friends.count) friends:")
        for afriend in friends{
            print(afriend.name)
        }
    }
    
    func isFriends(with person:Person) -> Bool{
        // let frcopy = self.friends
        for afriend in friends{
            if afriend == person{
                return true
            }
        }
        return false
    }
}

class SuggestionQueue:NSObject{
    
    var visited:[Person] = []
    var stack:[Person] = []
    
    var myself:Person
    var notFriends:[Person] = []
    
    init(for person:Person) {
        
        self.myself = person
        visited.append(myself)
        stack.append(contentsOf: myself.friends)
        
        while !stack.isEmpty{
            
            for stacked in stack{
                let frindx = stack.index(of: stacked)!
                
                if !visited.contains(stacked){
                    visited.append(stacked)
                    stack.append(contentsOf: stacked.friends)
                    
                    // if not a friend...
                    if !myself.isFriends(with: stacked){
                        notFriends.append(stacked)
                    }
                }
                stack.remove(at: frindx)
            }
        }
        
        if notFriends.count > 0{
            print("Not friends with... ")
            for notafriend in self.notFriends{
                print(notafriend.name)
            }
        }
    }
}

// Creating People....
let p_a = Person(with: "Arnold")
let p_b = Person(with: "Bart")
let p_c = Person(with: "Carlos")
let p_d = Person(with: "Daniel")
let p_e = Person(with: "Eva")
let p_f = Person(with: "Frank")
let p_g = Person(with: "Gilbert")
let p_h = Person(with: "Herbert")

// Creating Friends...
p_a.addFriend(friend: p_b)
p_a.addFriend(friend: p_c)
p_c.addFriend(friend: p_d)
p_c.addFriend(friend: p_e)
p_d.addFriend(friend: p_e)
p_d.addFriend(friend: p_f)
p_d.addFriend(friend: p_g)

p_a.printFriends()

var theQ = SuggestionQueue(for: p_a)




