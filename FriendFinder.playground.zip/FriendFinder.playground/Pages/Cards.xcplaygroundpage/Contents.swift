//: [Previous](@previous)

import Foundation

extension MutableCollection where Indices.Iterator.Element == Index {
    /// Shuffles the contents of this collection.
    mutating func shuffle() {
        let c = count
        guard c > 1 else { return }
        
        for (firstUnshuffled , unshuffledCount) in zip(indices, stride(from: c, to: 1, by: -1)) {
            let d: IndexDistance = numericCast(arc4random_uniform(numericCast(unshuffledCount)))
            guard d != 0 else { continue }
            let i = index(firstUnshuffled, offsetBy: d)
            swap(&self[firstUnshuffled], &self[i])
        }
    }
}

enum rank{
    case jack, queen, king;
    case ace, two, three, four, five, six, seven, eight, nine, ten;
}

enum suite{
    case diamonds, hearts, spades, clubs;
}

public class DeckOfCards{
    var cards: [Card] = []
    
    struct Card{
        var rank: rank
        var suite: suite
        func printCard(){
            print("\(rank) of \(suite)")
        }
    }
    
    func createDeck(){
        let ranks = [rank.ace, rank.two, rank.three, rank.four, rank.five, rank.six, rank.seven, rank.eight, rank.nine, rank.ten, rank.jack, rank.queen, rank.king]
        let suites = [suite.clubs, suite.diamonds, suite.hearts, suite.spades]
        
        for arank in ranks{
            for asuite in suites{
                cards.append(Card(rank: arank, suite: asuite))
            }
        }
    }
}

let newDeck = DeckOfCards()
newDeck.createDeck()

print("-------------------")
print("-- Ordered Cards --")
print("-------------------")

for acard in newDeck.cards{
    acard.printCard()
}

print("-------------------")
print("--    Shuffled   --")
print("-------------------")

newDeck.cards.shuffle()

for shuff in newDeck.cards{
    shuff.printCard()
}


//: [Next](@next)
