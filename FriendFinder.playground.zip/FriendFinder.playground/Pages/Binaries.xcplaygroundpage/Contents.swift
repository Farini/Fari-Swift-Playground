//: [Previous](@previous)

import Foundation

func updateBits(n:UInt32, m:UInt32, i:UInt32, j:UInt32) -> UInt32{
    print("Vars...")
    
    let allOnes:UInt32 = ~0
    print("Ones: " + String(allOnes, radix:2))
    
    let left = allOnes << (j+1)
    print("Left: " + String(left, radix:2))
    
    let right = ((1 << i) - 1)
    print("Right: " + String(right, radix:2))
    
    let mask = left | right
    print("Mask: " + String(mask, radix:2))
    
    let n_cleared = n & mask
    print("n_clear: " + String(n_cleared, radix:2))
    
    let m_shifted = m << i
    print("Shifting: " + String(m_shifted, radix:2))
    
    let rres = n_cleared | m_shifted
    
    print("Result: " + String(rres, radix:2))
    
    return n_cleared | m_shifted
    
}

let nn:UInt32 = 0b10000000000
let mm:UInt32 = 0b00000010011


let ii = UInt32(2)
let jj = UInt32(6)

updateBits(n: nn, m: mm, i: ii, j: jj)
print("\n****\n")

let initialBits:UInt8 = 0b00001111
let invertedBits = ~initialBits


func printBinary(_ n: Int, terminator: String = "\n") {
    if n < 2 {
        print(n, terminator: terminator)
    }
    else {
        printBinary(n / 2, terminator: "")
        print(n % 2, terminator: terminator)
    }
}

printBinary(11)
printBinary(170)
printBinary(23)
printBinary(1023)

print("\n****\n")

func pad(string : String, toSize: Int) -> String {
    var padded = string
    for _ in 0..<(toSize - string.characters.count) {
        padded = "0" + padded
    }
    return padded
}

let num = 22
let str = String(num, radix: 2)
print(str) // 10110
print(pad(string: str, toSize: 8))  // 00010110


//: [Next](@next)
